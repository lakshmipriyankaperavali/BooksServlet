package com.bookservlet;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bookservlet.UserBean;
import com.bookservlet.ConnectionProvider;

public class UserDao {
	 private Connection conn;

	    public UserDao() {
	    	conn = ConnectionProvider.getConnection();
	    }

	    public void addUser(UserBean userBean) {
	        try {
	        	String sql = "INSERT INTO users11(userid, name,price)" +
	    		" VALUES (?, ?, ? )";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, userBean.getId());
	            ps.setString(2, userBean.getName());
	            ps.setInt(3, userBean.getPrice());            
	            ps.executeUpdate();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	       

	        
	        }
	    }
	
