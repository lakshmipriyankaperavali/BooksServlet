package com.login;
import com.login.Books;
import com.login.BookDaoImpl;
import com.login.BookDao;
public class AccessBook {
// TODO Auto-generated method stub
		 public static void main(String[] args) {

		        BookDao bookDao = new BookDaoImpl();

		        for (Books book : bookDao.getAllBooks()) {
		            System.out.println("Book ISBN : " + book.getIsbn());
		        }

		        //update student
		        Books book = bookDao.getAllBooks().get(1);
		        book.setBookName("Algorithms");
		        bookDao.saveBook(book);
		        for (Books book1 : bookDao.getAllBooks()) {
		            System.out.println("Book Name : " + book1.getBookName()+" Id:" + book1.getIsbn());
		        }

	}

}
