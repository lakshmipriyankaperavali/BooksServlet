package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.login.UserBean;

public class BookDaoBook {

private Connection conn;

public void saveBook(UserBean book) throws  ClassNotFoundException
{
String url="jdbc:mysql://localhost:3306/priyanka1";
String username="root";
String password="Vennu@sydney";
try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection(url,username,password);
String qr="insert into book values(?,?,?)";

PreparedStatement ps=conn.prepareStatement(qr);
ps.setInt(1, book.getBid());
ps.setString(2, book.getBName());
ps.setInt(3, book.getPrice());
ps.executeUpdate();
conn.commit();
}catch(SQLException e)
{
e.printStackTrace();
}
}
}
