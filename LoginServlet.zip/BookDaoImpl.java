package com.login;
import com.login.BookDao;
import com.login.Books;
import java.util.ArrayList;
import java.util.List;

public class BookDaoImpl implements BookDao{

	private List<Books> books;

    public BookDaoImpl() {
        books = new ArrayList<>();
        books.add(new Books(1, "Java"));
        books.add(new Books(2, "Python"));
        books.add(new Books(3, "Android"));
    }

    @Override
    public List<Books> getAllBooks() {
        return books;
    }

    public Books getBookByIsbn(int isbn) {
        return books.get(isbn);
    }
    public void saveBook(Books book) {
        books.add(book);
    }
    public void deleteBook(Books book) {
        books.remove(book);
    }

	@Override
	public void saveUserBean(UserBean book) {
		// TODO Auto-generated method stub
		
	}
}