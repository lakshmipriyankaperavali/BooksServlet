package com.login;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamConcateExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> alphabets=Arrays.asList("A","B","C");
		List<String> names=Arrays.asList("Arjun","Bhargav","Charan");
		Stream<String> opstream=Stream.concat(alphabets.stream(),names.stream());
		opstream.forEach(str->System.out.println(str+""));
		System.out.println();
		Stream<Integer> streamOfNumbers=Stream.of(7,2,5,9,4,3,1);
		System.out.println(streamOfNumbers.filter(i->i>6).count());
}

}
