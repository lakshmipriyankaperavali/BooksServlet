package com.login;

public class UserBean {

	   private int Bid;
	    private String BName;
	    private int price;
		public int getBid() {
			return Bid;
		}
		public void setBid(int bid) {
			Bid = bid;
		}
		public String getBName() {
			return BName;
		}
		public void setBName(String bName) {
			BName = bName;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
}
	        
	    