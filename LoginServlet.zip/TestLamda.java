package com.login;


interface TestPi{
	public int  getsum(int x,int y);
}
//class PiClass implements TestPi{
	
//}
public class TestLamda {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TestPi pp=new PiClass();
		//pp.getpi();
		TestPi p=(x,y)->x+y;
		System.out.println("sum value is:"+p.getsum(5,5));
	}

}
